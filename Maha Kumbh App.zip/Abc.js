// Initialize Firebase
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-app.firebaseapp.com",
  databaseURL: "https://your-app.firebaseio.com",
  projectId: "your-app-id",
  storageBucket: "your-app.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id",
};
firebase.initializeApp(firebaseConfig);

const db = firebase.firestore();

// Store lost item
function reportLostItem() {
  const lostItem = prompt("Please enter the lost item details:");
  if (lostItem) {
    db.collection("lost-items").add({
      item: lostItem,
      reportedAt: firebase.firestore.FieldValue.serverTimestamp(),
    })
    .then(() => alert("Lost item reported successfully!"))
    .catch((error) => console.error("Error adding document: ", error));
  }
}
