// app.js

let map;
let userLocation;
let trafficData = "No traffic updates available yet."; // Placeholder for traffic info

// Initialize Google Map
function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: 25.5, lng: 81.9 }, // Set a default location for Kumbh Mela
    zoom: 13,
  });

  // Try to get user's current location
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition((position) => {
      userLocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
      };
      map.setCenter(userLocation);

      // Add a marker for user's location
      new google.maps.Marker({
        position: userLocation,
        map: map,
        title: "Your Location",
      });
    });
  }

  // Placeholder for traffic info
  document.getElementById("traffic-info").innerText = trafficData;
}

// Emergency button functionality
function sendEmergencyAlert() {
  const message = {
    type: "emergency",
    location: userLocation,
    timestamp: new Date(),
  };

  // Send alert to emergency services (Use Firebase or another backend system)
  alert("Emergency alert sent!");
  console.log(message); // In real application, send this to the backend
}

// Lost & Found functionality
function reportLostItem() {
  const lostItem = prompt("Please enter the lost item details:");
  if (lostItem) {
    // Store lost item in Firebase or another backend system
    alert(`Lost item reported: ${lostItem}`);
  }
}

// Weather API integration
function fetchWeather() {
  const weatherApiKey = "YOUR_WEATHER_API_KEY";
  const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=Allahabad&appid=${weatherApiKey}&units=metric`;

  fetch(weatherUrl)
    .then((response) => response.json())
    .then((data) => {
      const weatherInfo = `Temp: ${data.main.temp}°C, Condition: ${data.weather[0].description}`;
      document.getElementById("weather-info").innerText = weatherInfo;
    });
}

// Switch languages (For now, just toggling text in English and Hindi)
function switchLanguage(language) {
  if (language === "en") {
    document.getElementById("traffic-info").innerText = "Traffic Information: Loading...";
    document.getElementById("weather-info").innerText = "Weather Information: Loading...";
  } else if (language === "hi") {
    document.getElementById("traffic-info").innerText = "यातायात जानकारी: लोड हो रहा है...";
    document.getElementById("weather-info").innerText = "मौसम जानकारी: लोड हो रहा है...";
  }
}

// Fetch weather when the page loads
fetchWeather();

// Initialize the map on page load
window.onload = initMap;
